# jeeachinto - easy connections

Created to allow communication of NAO and PEPPER robots in an easier way
